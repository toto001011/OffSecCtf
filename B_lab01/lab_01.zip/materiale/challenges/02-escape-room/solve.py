#!/usr/bin/env python3
from pwn import *

context.binary = elf = ELF('./escape_room', checksec=False)

p = process(elf.path)

# Your exploit here

p.interactive()
