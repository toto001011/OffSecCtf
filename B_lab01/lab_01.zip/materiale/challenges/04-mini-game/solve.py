from pwn import *

exe = ELF("./mini_game")
p = exe.process()

p.interactive()
