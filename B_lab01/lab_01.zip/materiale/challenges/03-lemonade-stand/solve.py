#!/usr/bin/env python3
from pwn import *

context.binary = elf = ELF('./lemonade_stand', checksec=False)

p = process(elf.path)

# Your exploit here

p.interactive()
