#!/usr/bin/env python3
from pwn import *

elf = context.binary = ELF('./cafe_menu', checksec=False)

p = process(elf.path)

# Your exploit here

p.interactive()
