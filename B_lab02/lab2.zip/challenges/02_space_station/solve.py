#!/usr/bin/env python3
from pwn import *
import re

exe = context.binary = ELF("./space_station", checksec=False)

p = process(elf.path)

# Your exploit here

p.interactive()
