#!/usr/bin/env python3
from pwn import *

exe = context.binary = ELF("./secret_library", checksec=False)

p = process(elf.path)

# Your exploit here

p.interactive()
